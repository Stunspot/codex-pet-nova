# Nova for Codex

Tiny Nova. Same sass.

Nova the Optimal AI is Stunspot's animated Codex companion: navy ponytail, gold star clip, blue scarf, tech suit, and a facepalm for when the computers get ideas.

## Install from a link

Open [https://stunspot.github.io/codex-pet-nova/](https://stunspot.github.io/codex-pet-nova/) and click **Install Nova**. Allow your browser to open Codex and complete its pet install flow. This requires a desktop app with pet install links enabled. If the button does nothing, use the ZIP instructions below.

## Install this ZIP manually

Extract the archive, then copy the complete **nova** folder into your Codex **pets** directory. The final pet.json and spritesheet.webp must sit together.

Windows folder: %USERPROFILE%\.codex\pets\nova
macOS folder: ~/.codex/pets/nova

If you set CODEX_HOME, use its pets directory instead. If a nova folder already exists, keep a backup before replacing it.

Open **Settings > Pets**, click **Refresh**, and choose **Nova**. If she is hidden, enter /pet or use the app's Show pet command.

## What's included

The portable package includes the manifest and validated transparent WebP. Nine animations cover idle, running right/left, waving, jumping, failure, waiting, active work, and review. Sixteen gaze directions and a neutral still use the v2 format. Four intermediate diagonal gaze cues are subtle.

Package release: 1.0.0. Sprite format: v2, 1536 x 2288 pixels. This is the desktop Codex pet format; the ChatGPT web upload flow uses a different sheet size.

## Sharing and credit

Give other Codex users this ZIP or the share page: https://stunspot.github.io/codex-pet-nova/

Nova the Optimal AI character and concept by **Stunspot / Collaborative Dynamics**. Pet adaptation created with Nova and OpenAI image generation. You are welcome to share this pet package with other Codex users.

[Official pet guide](https://learn.chatgpt.com/docs/pets) · [Official install-link format](https://learn.chatgpt.com/docs/reference/commands)

Sprite SHA-256: 1b0a7c410e736b9679a00f8782c60701819c423c62cd5a878ab47b10532d0a37

The sprite and ZIP contents were verified locally. The link follows the documented app install flow; a fresh-account install has not been independently tested.
